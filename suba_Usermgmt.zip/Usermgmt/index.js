// Load users from DummyJSON API on page load
window.onload = function () {
  fetch('https://dummyjson.com/users')
    .then(res => res.json())
    .then(data => {
      const userList = document.getElementById('userList');
      data.users.forEach(user => {
        const li = document.createElement('li');
        li.textContent = `${user.firstName} ${user.lastName}`;
        userList.appendChild(li);
      });
    });
};

// Add user using DummyJSON POST API
function addUser() {
  const name = document.getElementById('name').value;
  const job = document.getElementById('job').value;

  fetch('https://dummyjson.com/users/add', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      firstName: name,
      lastName: job
    })
  })
    .then(res => res.json())
    .then(user => {
      const li = document.createElement('li');
      li.textContent = `${user.firstName} ${user.lastName}`;
      document.getElementById('userList').appendChild(li);

      // Clear input fields
      document.getElementById('name').value = '';
      document.getElementById('job').value = '';
    });
}
